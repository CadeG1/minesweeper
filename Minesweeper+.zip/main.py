import random
from PyQt6.QtWidgets import QPushButton, QApplication, QMainWindow, QWidget, QGridLayout, QLabel, QVBoxLayout, \
    QStackedWidget, QComboBox, QLineEdit
from PyQt6.QtGui import QAction, QIcon, QMovie, QFont, QIntValidator
from PyQt6.QtCore import QSize, Qt, QCoreApplication, QPoint, QPropertyAnimation, QObject, QEvent, QTimer, QTime

# CS335 Project by William Hands, Cade Gallenstein, Jared Conn
# No generative AI was used for this project.

# Global constants for settings menu
DIMENSIONS_EASY = 10
DIMENSIONS_MEDIUM = 12
DIMENSIONS_HARD = 16


# Deals with changing window between settings, main and game menu
class WindowChange(QWidget):
    def __init__(self):
        super(WindowChange, self).__init__()

        # Initialize as Stacked widget to keep sizing and information between widgets
        self.stacked_widget = QStackedWidget(self)

        self.settings = Settings()

        self.mainMenu = QWidget()
        self.setupMenu()

        self.playGame = QWidget()
        self.Game = None

        self.viewSettings = QWidget()
        self.setupSettings()

        # Define each different widget "page"
        self.stacked_widget.addWidget(self.mainMenu)
        self.stacked_widget.addWidget(self.viewSettings)
        self.stacked_widget.addWidget(self.playGame)

        self.layout = QVBoxLayout(self)
        self.layout.addWidget(self.stacked_widget)

        self.setWindowTitle("Minesweeper")
        self.resize(600, 750)

    # Setup menu page
    def setupMenu(self):

        self.setStyleSheet("background-color: lightgray;")

        layout = QVBoxLayout(self.mainMenu)

        title_label = QLabel("Minesweeper Game")
        movie = QMovie("minesweeper.gif")
        title_label.setMovie(movie)
        movie.start()
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        layout.addWidget(title_label)

        # Pathing to Normal gamemode
        normal_button = QPushButton("Normal")
        normal_button.clicked.connect(self.showNormal)
        layout.addWidget(normal_button)

        # Pathing to Extreme gamemode
        extreme_button = QPushButton("Extreme")
        extreme_button.clicked.connect(self.showExtreme)
        layout.addWidget(extreme_button)

        # Pathing to Settings menu
        settings_button = QPushButton("Settings")
        settings_button.clicked.connect(self.showSettings)
        layout.addWidget(settings_button)

    # Show the normal gamemode page
    def showNormal(self):
        self.Game = GamePlayer(self, False)
        self.stacked_widget.setCurrentIndex(2)

    # Show the extreme gamemode page
    def showExtreme(self):
        self.Game = GamePlayer(self, True)
        self.stacked_widget.setCurrentIndex(2)

    # Show the menu page
    def showMenu(self):
        if (self.Game):
            self.playGame.deleteLater()
            self.playGame = QWidget()
            self.stacked_widget.addWidget(self.playGame)
        self.stacked_widget.setCurrentIndex(0)
        self.setWindowTitle("Minesweeper")

    # Show the settings menu
    def setupSettings(self):
        layout = QVBoxLayout(self.viewSettings)

        # helper functions
        def changeHeight(index):
            final = 0
            if index == 0:
                final = DIMENSIONS_EASY
            elif index == 1:
                final = DIMENSIONS_MEDIUM
            else:
                final = DIMENSIONS_HARD
            self.settings.ChangeHeight(final)

        def changeWidth(index):
            final = 0
            if index == 0:
                final = DIMENSIONS_EASY
            elif index == 1:
                final = DIMENSIONS_MEDIUM
            else:
                final = DIMENSIONS_HARD
            self.settings.ChangeWidth(final)

        def changeMines(index):
            try:
                self.settings.ChangeMines(int(index))
            except ValueError:
                pass

        # Setup animation
        movie = QMovie("rainbow.gif")

        # Setup dimensions label
        height_label = QLabel()
        height_label.setMovie(movie)
        height_label.setLayout(QVBoxLayout())
        height_label.layout().addWidget(QLabel("Choose the play area dimensions:"))
        height_label.setFixedHeight(100)
        height_label.setStyleSheet("font-size: 16pt; font-style: italic; font-weight: bold;")

        # Setup dimensions section
        height_box = QComboBox()
        height_box.addItems(
            ['%sx%s' % (DIMENSIONS_EASY, DIMENSIONS_EASY), '%sx%s' % (DIMENSIONS_MEDIUM, DIMENSIONS_MEDIUM),
             '%sx%s' % (DIMENSIONS_HARD, DIMENSIONS_HARD)])
        if self.settings.Height == DIMENSIONS_EASY:
            height_box.setCurrentIndex(0)
        elif self.settings.Height == DIMENSIONS_MEDIUM:
            height_box.setCurrentIndex(1)
        else:
            height_box.setCurrentIndex(2)
        height_box.currentIndexChanged.connect(changeHeight)
        height_box.currentIndexChanged.connect(changeWidth)
        height_box.setFont(QFont('Arial'))
        height_label.layout().addWidget(height_box)
        layout.addWidget(height_label)

        # Setup mines label
        mines_label = QLabel()
        mines_label.setMovie(movie)
        mines_label.setLayout(QVBoxLayout())
        mines_label.layout().addWidget(QLabel("Type the amount of mines:"))
        mines_label.setFixedHeight(100)
        mines_label.setStyleSheet("font-size: 16pt; font-style: italic; font-weight: bold;")

        # Setup mines text box
        mines_box = QLineEdit()
        mines_box.setValidator(QIntValidator())
        mines_box.setText("10")
        mines_box.setMaxLength(2)
        mines_box.setFont(QFont("Arial"))
        mines_box.textEdited.connect(changeMines)
        mines_label.layout().addWidget(mines_box)
        layout.addWidget(mines_label)

        movie.start()

        # Credits and spacing
        spacer = QLabel("<a href='http://kimasendorf.com/12c/'>Rainbow Gif Credits</a> "
                        "<a href='http://www.skaip.org/bomb-emoticon'>Bomb Gif Credits</a> "
                        "<a href='https://commons.wikimedia.org/wiki/File:Minesweeper_flag.svg'>Flag Icon Credits</a>")
        spacer.setTextFormat(Qt.TextFormat.RichText)
        spacer.setTextInteractionFlags(Qt.TextInteractionFlag.TextBrowserInteraction)
        spacer.setOpenExternalLinks(1)
        spacer.setWordWrap(True)
        spacer.setFixedWidth(110)
        layout.addWidget(spacer)

        # Setup return button
        back_button = QPushButton("Back")
        back_button.clicked.connect(self.showMenu)
        layout.addWidget(back_button)

    def showSettings(self):
        self.stacked_widget.setCurrentIndex(1)


# Define front end Game player for both Normal and Extreme gamemode
class GamePlayer(QMainWindow):
    def __init__(self, WindowChange, isExtreme):

        super(GamePlayer, self).__init__()

        self.WindowChange = WindowChange

        self.img_pole = QIcon("./pole.png")

        # Define Grid layout for buttons to be places
        self.layout = QGridLayout(WindowChange.playGame)

        # Take in information from settings menu
        self.height = WindowChange.settings.Height
        self.width = WindowChange.settings.Width
        self.mines = WindowChange.settings.Mines

        self.board = Board(self.height, self.width, self.mines)

        self.isExtreme = isExtreme

        # List of buttons
        self.cells = []

        # Number of buttons marked with a flag
        self.flaggedBoxes = 0
        # List of coordinates with cells of correctly marked mines
        self.checkedmines = []
        # Button size
        self.button_height = self.button_width = 38
        # Padding between buttons
        self.button_indent = 1

        # Turn counter for extreme gamemode
        self.turnCounter = 0

        # Determine if we can re arrange board
        self.canExtreme = True

        # Arrangement of elements in the window
        self.widget = QWidget()
        self.setCentralWidget(self.widget)

        # Fixed size of the playing field for  number of buttons
        self.width_size = self.height * self.button_height + (self.height - 1) * self.button_indent
        self.height_size = self.width * self.button_width + (self.width - 1) * self.button_indent
        self.setFixedSize(QSize(self.width_size + 30, self.height_size + 40))

        self.localMines = self.mines
        self.timer_counter = 0

        # Define timer to keep track of current time on run
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.updateWindowTitle)
        self.timer_interval = 100
        self.timer.start(self.timer_interval)

        # Creating a grid of buttons
        for i in range(self.height):
            for j in range(self.width):
                self.button = QPushButton("Button ", self)

                # Setting the size of buttons
                self.button.setFixedSize(QSize(self.button_height, self.button_width))

                self.button.setCheckable(True)
                self.button.setText('')
                self.button.clicked.connect(self.isClicked)

                # Flag of the pressed button
                self.button.is_pressed = False

                # Flag of a marked mine
                self.button.mine_note = False

                # Status of the buttons after the victory
                self.button.win = False

                # Redefining the right mouse button
                self.button.installEventFilter(self)
                self.layout.addWidget(self.button, i, j)

                # Setting coordinates to buttons
                self.button.x = i
                self.button.y = j

                # Adding buttons to the list
                self.cells.append(self.button)

        # Create win label for animation
        self.win_label = QLabel(self)
        self.win_label.setText("Winner!")
        self.win_label.setStyleSheet("QLabel {font: bold 50px;}")
        self.layout.addWidget(self.win_label, self.height_size, self.width_size)
        self.win_label.hide()

        # Helper function for leaving game page and clearing all information
        def leaverHelper():
            while self.layout.count():
                item = self.layout.takeAt(0)
                widget = item.widget()
                if widget:
                    widget.deleteLater()
            self.timer.timeout.disconnect(self.updateWindowTitle)
            self.WindowChange.setWindowTitle('Minesweeper')
            WindowChange.showMenu()

        back_button = QPushButton("Back")
        back_button.setFixedSize(QSize(self.button_height, self.button_width))
        back_button.clicked.connect(leaverHelper)
        self.layout.addWidget(back_button)

    # Update window title to show game title, current mines, and time
    def updateWindowTitle(self):
        self.timer_counter += 0.1
        self.WindowChange.setWindowTitle(
            f"Minesweeper Game  |  Mines: {self.localMines}  |  Time: {round(self.timer_counter * (self.timer_interval / 100), 2)}")

    # Called when a button is clicked and perform action depending on what was selected
    def isClicked(self):
        # The object of the pressed button
        sender = self.sender()
        sender.setChecked(True)

        if self.canExtreme:
            self.turnCounter += 1

        # If the user clicks on a flagged spot, ignore click
        if not sender.mine_note:
            sender.is_pressed = True

            # Number of buttons pressed
            self.pressedButtons = len(list(filter(self.check_true, [i.is_pressed for i in self.cells])))

            # Checking the victory conditions (if the last closed cell opens)
            self.win_check()

            # Clicking on a mine
            if self.board.pole[sender.x][sender.y].mine:
                self.mine_press(sender)
            # Counting the mines around the pressed button
            elif self.board.pole[sender.x][sender.y].around_mines > 0:
                sender.setText(str(self.board.pole[sender.x][sender.y].around_mines))

                # Number custom colors
                if sender.text() == '1':
                    sender.setStyleSheet('QPushButton {color: #3F51B5; font: bold 20px;}')
                if sender.text() == '2':
                    sender.setStyleSheet('QPushButton {color: #8B0000; font: bold 20px;}')
                if sender.text() == '3':
                    sender.setStyleSheet('QPushButton {color: #FF0000; font: bold 20px;}')
                if sender.text() == '4':
                    sender.setStyleSheet('QPushButton {color: #03A9F4; font: bold 20px;}')
                if sender.text() == '5':
                    sender.setStyleSheet('QPushButton {color: #006400; font: bold 20px;}')

            # If you clicked on an empty cell
            if self.board.pole[sender.x][sender.y].around_mines == 0 and self.board.pole[sender.x][
                sender.y].mine != True:
                self.rec_open(sender.x, sender.y)

            sender.setEnabled(False)
            if self.turnCounter % 3 == 0 and self.isExtreme and self.canExtreme:
                self.board.beExtreme(self.cells, self)

    def Recalculate(self, cell):

        # Number of buttons pressed
        self.pressedButtons = len(list(filter(self.check_true, [i.is_pressed for i in self.cells])))

        # Counting the mines around the pressed button
        if self.board.pole[cell.x][cell.y].around_mines > 0:
            cell.setText(str(self.board.pole[cell.x][cell.y].around_mines))

            # Number custom colors
            if cell.text() == '1':
                cell.setStyleSheet('QPushButton {color: #3F51B5; font: bold 20px;}')
            if cell.text() == '2':
                cell.setStyleSheet('QPushButton {color: #8B0000; font: bold 20px;}')
            if cell.text() == '3':
                cell.setStyleSheet('QPushButton {color: #FF0000; font: bold 20px;}')
            if cell.text() == '4':
                cell.setStyleSheet('QPushButton {color: #03A9F4; font: bold 20px;}')
            if cell.text() == '5':
                cell.setStyleSheet('QPushButton {color: #006400; font: bold 20px;}')

    @staticmethod
    def check_true(x):
        if x:
            return x

    # If mine selected, play mine exlode animation and stop timer
    def mine_press(self, sender):
        self.explode()
        self.timer.stop()

    # On click, determine if the board is in a winning position
    def win_check(self):
        if sorted(self.checkedmines) == sorted(self.board.rij) and self.check_buttons == self.mines:
            if self.pressedButtons == len(self.cells) - self.mines:
                self.checkedmines = []
                for i in self.cells:
                    i.win = True
                self.victory()
                self.timer.stop()

    # Delete cells and play victory animation
    def victory(self):
        for i in range(self.height):
            for j in range(self.width):
                item = self.layout.itemAtPosition(i, j)
                widget = item.widget()
                if widget:
                    widget.deleteLater()

        self.win_label.show()
        animation = QPropertyAnimation(self.win_label, b'pos', self)
        animation.setStartValue(QPoint(0, 0))
        animation.setKeyValueAt(0.2, QPoint(250, 250))
        animation.setKeyValueAt(0.4, QPoint(500, 0))
        animation.setKeyValueAt(0.6, QPoint(250, -250))
        animation.setKeyValueAt(0.8, QPoint(0, 0))
        animation.setEndValue(QPoint(250, 0))
        animation.setDuration(10000)
        animation.start()

    # Play animation for bomb exploding
    def explode(self):
        for i in range(self.height):
            for j in range(self.width):
                item = self.layout.itemAtPosition(i, j)
                widget = item.widget()
                if widget:
                    widget.hide()

        self.loading = QLabel(self)
        self.loading.resize(500, 500)
        gif = QMovie('explosion2.gif')
        gif.setFormat(b'gif')
        gif.setScaledSize(QSize(600, 600))
        self.loading.setMovie(gif)
        gif.start()
        self.layout.addWidget(self.loading, self.height, self.width)

    # When empty space is clicked, continue to click on unpressed empty spaces        
    def rec_open(self, x, y):
        self.canExtreme = False
        for i in self.cells:
            if not i.is_pressed:
                if i.x == x and i.y == y + 1:
                    i.click()
                if i.x == x + 1 and i.y == y:
                    i.click()
                if i.x == x - 1 and i.y == y:
                    i.click()
                if i.x == x and i.y == y - 1:
                    i.click()
                if i.x == x + 1 and i.y == y + 1:
                    i.click()
                if i.x == x - 1 and i.y == y - 1:
                    i.click()
                if i.x == x - 1 and i.y == y + 1:
                    i.click()
                if i.x == x + 1 and i.y == y - 1:
                    i.click()

        QTimer.singleShot(500, self.set_canExtreme_true)

    # Helper to time when a click can be used to change the bomb location
    def set_canExtreme_true(self):
        self.canExtreme = True

    # On click, place or remove mine flag from button
    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.MouseButtonPress:
            if event.button() == Qt.MouseButton.RightButton:
                # Marking of mines on the field
                if not obj.is_pressed and not obj.win:
                    if not obj.mine_note:
                        self.localMines -= 1
                        # PLACE FLAG IMAGE HERE
                        obj.setIcon(QIcon(self.img_pole))
                        obj.setIconSize(QSize(34, 34))
                        obj.mine_note = True
                        obj.setCheckable(False)

                        if self.board.pole[obj.x][obj.y].mine:
                            if [obj.x, obj.y] not in self.checkedmines:
                                self.checkedmines.append([obj.x, obj.y])

                    else:
                        self.localMines += 1
                        obj.mine_note = False
                        obj.setIcon(QIcon())
                        obj.setCheckable(True)
                        if [obj.x, obj.y] in self.checkedmines:
                            self.checkedmines.remove([obj.x, obj.y])

                # Number of buttons marked with a flag
                self.check_buttons = len(list(filter(self.check_true, [i.mine_note for i in self.cells])))
                self.win_check()

        return QObject.event(obj, event)


# Define a Cell within the board
class Cell:
    def __init__(self, around_mines, mine):
        self.around_mines = around_mines
        self.mine_list = []
        self.mine = mine
        self.fl_open = False


# Backend for game and giving information
class Board:
    def __init__(self, height=12, width=12, mines=10):

        # List size
        self.M = height
        self.N = width

        # Number of mines
        self.mines = mines

        # Filling the list of cells with zeros
        self.pole = [[(Cell(0, False)) for i in range(self.N)] for i in range(self.M)]

        # List with mines
        self.rij = []

        # Filling the field with mines
        mine_count = 0
        while mine_count < self.mines:
            r = [random.randrange(self.N), random.randrange(self.M)]
            if r not in self.rij:
                self.rij.append(r)
                self.pole[r[0]][r[1]].mine = True
                mine_count += 1

        # Counting the number of mines around each cell
        for i in range(self.M):
            for j in range(self.N):
                around_mines = 0
                for x in range(-1, 2):
                    for y in range(-1, 2):
                        if 0 <= (i + x) < self.M and 0 <= (j + y) < self.N:
                            if self.pole[i + x][j + y].mine:
                                around_mines += 1
                                self.pole[i][j].mine_list.append([i + x, j + y])
                if self.pole[i][j].mine and around_mines > 0:
                    around_mines -= 1
                    self.pole[i][j].mine_list.remove([i, j])
                self.pole[i][j].around_mines = around_mines
                around_mines = 0

    # Logic for determining which mines can be moved
    def beExtreme(self, cells, Game):
        movingMine = 0
        validCells = []

        # Loop through all cells to see if its a bomb or a valid cell to move
        for cell in cells:
            if (not cell.is_pressed):
                if (self.pole[cell.x][cell.y].mine and not cell.mine_note):
                    movingMine += 1
                    self.pole[cell.x][cell.y].mine = False
                    self.rij.remove([cell.x, cell.y])

                if (not cell.mine_note and not cell.is_pressed):
                    validCells.append([cell.x, cell.y])

        # After gathering all mines, move them to a valid cell
        while movingMine > 0:
            r = random.randrange(len(validCells) - 1)
            self.rij.append(validCells[r])
            self.pole[validCells[r][0]][validCells[r][1]].mine = True
            validCells.remove(validCells[r])
            movingMine -= 1

        # Loop through the board and recalculate the around mines for each cell
        for i in range(self.M):
            for j in range(self.N):
                around_mines = 0
                self.pole[i][j].mine_list = []
                for x in range(-1, 2):
                    for y in range(-1, 2):
                        if 0 <= (i + x) < self.M and 0 <= (j + y) < self.N:
                            if self.pole[i + x][j + y].mine:
                                around_mines += 1
                                self.pole[i][j].mine_list.append([i + x, j + y])
                if self.pole[i][j].mine and around_mines > 0:
                    around_mines -= 1
                    self.pole[i][j].mine_list.remove([i, j])
                self.pole[i][j].around_mines = around_mines
                around_mines = 0

        # Change the number shown on each cell to show the new number of mines
        for cell in cells:
            if cell.is_pressed:
                Game.Recalculate(cell)


# Settings menu class to keep track of settings values
class Settings:
    def __init__(self, height=12, width=12, mines=10):
        self.Height = height
        self.Width = width
        self.Mines = mines

    def ChangeHeight(self, input):
        self.Height = input

    def ChangeWidth(self, input):
        self.Width = input

    def ChangeMines(self, input):
        self.Mines = input


if __name__ == "__main__":
    app = QApplication([])
    main_window = WindowChange()
    main_window.show()
    app.exec()
